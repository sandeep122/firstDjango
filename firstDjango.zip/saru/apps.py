from django.apps import AppConfig


class SaruConfig(AppConfig):
    name = 'saru'
